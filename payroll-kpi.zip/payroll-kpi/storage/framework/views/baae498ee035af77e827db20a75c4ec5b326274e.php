<form method="POST" action="<?php echo e(isset($segment) ? route('segmen.update', $segment->id) : route('segmen.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($segment)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Nama</label>
        <div class="col-sm-10">
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $segment->segment ?? '')); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-sm-2 col-form-label">Divisi</label>
        <div class="col-sm-10">
            <select class="form-select" name="division" aria-label="Default select example">
                <option value="">- Pilih divisi -</option>
                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($division->id); ?>"
                        <?php echo e(isset($segment) && $segment->division_id == $division->id ? 'selected' : ''); ?>>
                        <?php echo e($division->division); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 text-center">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($segment) ? 'Update' : 'Simpan'); ?></button>
        </div>
    </div>
</form>
<?php /**PATH /Users/user/payroll-kpi/resources/views/master/segmen/form.blade.php ENDPATH**/ ?>