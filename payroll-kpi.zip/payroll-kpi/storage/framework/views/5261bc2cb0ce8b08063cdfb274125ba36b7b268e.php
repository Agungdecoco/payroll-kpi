<form method="POST"
    action="<?php echo e(isset($allowance) ? route('tunjangan.update', $allowance->id) : route('tunjangan.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($allowance)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Nama</label>
        <div class="col-sm-10">
            <input type="text" name="nama" class="form-control"
                value="<?php echo e(old('nama', $allowance->allowance ?? '')); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputNumber" class="col-sm-2 col-form-label">Jumlah</label>
        <div class="col-sm-10">
            <input type="number" name="amount" class="form-control"
                value="<?php echo e(old('amount', $allowance->amount ?? '')); ?>">
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 text-center">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($allowance) ? 'Update' : 'Simpan'); ?></button>
        </div>
    </div>
</form>
<?php /**PATH /Users/user/payroll-kpi/resources/views/master/tunjangan/form.blade.php ENDPATH**/ ?>