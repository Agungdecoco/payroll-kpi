<form method="POST" action="<?php echo e(isset($division) ? route('divisi.update', $division->id) : route('divisi.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($division)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Nama</label>
        <div class="col-sm-10">
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $division->division ?? '')); ?>">
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 text-center">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($division) ? 'Update' : 'Simpan'); ?></button>
        </div>
    </div>
</form>
<?php /**PATH /Users/user/payroll-kpi/resources/views/master/divisi/form.blade.php ENDPATH**/ ?>