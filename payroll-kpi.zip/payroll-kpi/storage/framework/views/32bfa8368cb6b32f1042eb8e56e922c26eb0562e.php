<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Edit KPI Score</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item">KPI</li>
                    <li class="breadcrumb-item">Score</li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">

                <form class="row g-3" action="<?php echo e(route('kpi.update', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-lg-6">
                        <input type="hidden" class="form-control" name="user_id" value="<?php echo e($user->id); ?>">

                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Kedisiplinan</h5>

                                <?php $__currentLoopData = $disciplineScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" class="form-control" name="disciplineId[<?php echo e($index); ?>]"
                                        value="<?php echo e($score->parameter_id); ?>">
                                    <div class="col-12">
                                        <label for="inputDiscipline<?php echo e($index + 1); ?>"
                                            class="form-label"><?php echo e($score->parameter->parameter); ?></label>
                                        <input type="number" class="form-control" name="discipline[<?php echo e($index); ?>]"
                                            id="inputDiscipline<?php echo e($index + 1); ?>" value="<?php echo e($score->score); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>

                    <div class="col-lg-6">

                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Sikap</h5>

                                <?php $__currentLoopData = $attitudeScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" class="form-control" name="attitudeId[<?php echo e($index); ?>]"
                                        value="<?php echo e($score->parameter_id); ?>">
                                    <div class="col-12">
                                        <label for="inputAttitude<?php echo e($index + 1); ?>"
                                            class="form-label"><?php echo e($score->parameter->parameter); ?></label>
                                        <input type="number" class="form-control" name="attitude[<?php echo e($index); ?>]"
                                            id="inputAttitude<?php echo e($index + 1); ?>" value="<?php echo e($score->score); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>

                    <div class="col-lg-6">

                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Performa</h5>

                                <?php $__currentLoopData = $performanceScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" class="form-control" name="performanceId[<?php echo e($index); ?>]"
                                        value="<?php echo e($score->parameter_id); ?>">
                                    <div class="col-12">
                                        <label for="inputPerformance<?php echo e($index + 1); ?>"
                                            class="form-label"><?php echo e($score->parameter->parameter); ?></label>
                                        <input type="number" class="form-control" name="performance[<?php echo e($index); ?>]"
                                            id="inputPerformance<?php echo e($index + 1); ?>" value="<?php echo e($score->score); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/payroll-kpi/resources/views/score/edit.blade.php ENDPATH**/ ?>