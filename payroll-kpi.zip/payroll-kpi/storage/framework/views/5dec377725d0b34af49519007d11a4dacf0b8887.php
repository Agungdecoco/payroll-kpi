<form method="POST" action="<?php echo e(isset($level) ? route('level.update', $level->id) : route('level.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($level)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Nama</label>
        <div class="col-sm-10">
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $level->level ?? '')); ?>">
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 text-center">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($level) ? 'Update' : 'Simpan'); ?></button>
        </div>
    </div>
</form>
<?php /**PATH /Users/user/payroll-kpi/resources/views/master/level/form.blade.php ENDPATH**/ ?>